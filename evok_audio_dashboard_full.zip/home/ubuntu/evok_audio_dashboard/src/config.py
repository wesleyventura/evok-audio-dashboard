import os
from urllib.parse import urlparse

class Config:
    # Configuração do banco de dados
    DATABASE_URL = os.environ.get('DATABASE_URL')
    
    if DATABASE_URL:
        # Parse da URL do banco de dados do Render
        url = urlparse(DATABASE_URL)
        SQLALCHEMY_DATABASE_URI = f"mysql+pymysql://{url.username}:{url.password}@{url.hostname}:{url.port or 3306}/{url.path[1:]}"
    else:
        # Configuração local para desenvolvimento
        SQLALCHEMY_DATABASE_URI = "mysql+pymysql://evok_user:evok_password@localhost:3306/evok_audio_db"
    
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SECRET_KEY = os.environ.get('SECRET_KEY', 'dev-secret-key-change-in-production')
    
    # Configuração para produção
    DEBUG = os.environ.get('FLASK_ENV') != 'production'
    
    # Configuração de porta para Render
    PORT = int(os.environ.get('PORT', 5000))

