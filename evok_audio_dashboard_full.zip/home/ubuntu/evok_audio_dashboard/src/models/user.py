from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime

db = SQLAlchemy()

# Tabela de associação para funcionários na produção
producao_funcionarios = db.Table(
    'producao_funcionarios',
    db.Column('producao_id', db.Integer, db.ForeignKey('producao.id'), primary_key=True),
    db.Column('funcionario_id', db.Integer, db.ForeignKey('user.id'), primary_key=True)
)

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    nome = db.Column(db.String(100), nullable=False)
    departamento = db.Column(db.String(100), nullable=False)
    funcao = db.Column(db.String(100), nullable=False)
    salario = db.Column(db.Float, nullable=False)
    is_admin = db.Column(db.Boolean, default=False)
    pode_ver_funcionarios = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.now)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

    @property
    def custo_hora(self):
        return self.salario / 220  # 220 horas por mês

    def to_dict(self):
        return {
            'id': self.id,
            'username': self.username,
            'nome': self.nome,
            'departamento': self.departamento,
            'funcao': self.funcao,
            'salario': self.salario,
            'custo_hora': self.custo_hora,
            'is_admin': self.is_admin,
            'pode_ver_funcionarios': self.pode_ver_funcionarios,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

    def __repr__(self):
        return f'<User {self.username}>'

class Produto(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(100), nullable=False)
    categoria = db.Column(db.String(100), nullable=False)
    qtd_produzida_por_hora_funcionario = db.Column(db.Float, nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.now)

    # Relacionamento
    user = db.relationship('User', backref='produtos_criados')

    def to_dict(self):
        return {
            'id': self.id,
            'nome': self.nome,
            'categoria': self.categoria,
            'qtd_produzida_por_hora_funcionario': self.qtd_produzida_por_hora_funcionario,
            'user_id': self.user_id,
            'user_nome': self.user.nome if self.user else None,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

    def __repr__(self):
        return f'<Produto {self.nome}>'

class Producao(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    data_inicio = db.Column(db.Date, nullable=False)
    ordem_producao = db.Column(db.String(100), unique=True, nullable=False)
    horario_inicio = db.Column(db.DateTime, nullable=False)
    horario_fim = db.Column(db.DateTime)
    produto_id = db.Column(db.Integer, db.ForeignKey('produto.id'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)  # Usuário que criou a produção
    quantidade_produzida = db.Column(db.Float, nullable=False)
    status = db.Column(db.String(20), default='pendente')  # pendente, finalizada
    observacoes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.now)

    # Relacionamentos
    produto = db.relationship('Produto', backref='producoes')
    user = db.relationship('User', backref='producoes')
    funcionarios = db.relationship('User', secondary=producao_funcionarios, 
                                 backref=db.backref('producoes_trabalhadas', lazy='dynamic'),
                                 primaryjoin=id == producao_funcionarios.c.producao_id,
                                 secondaryjoin=User.id == producao_funcionarios.c.funcionario_id)

    def __repr__(self):
        return f'<Producao {self.ordem_producao}>'

    @property
    def horas_trabalhadas(self):
        if self.horario_fim and self.horario_inicio:
            delta = self.horario_fim - self.horario_inicio
            return delta.total_seconds() / 3600
        return 0

    @property
    def quantidade_esperada(self):
        if self.horas_trabalhadas > 0 and len(self.funcionarios) > 0:
            # Quantidade esperada baseada no número de funcionários
            return self.produto.qtd_produzida_por_hora_funcionario * self.horas_trabalhadas * len(self.funcionarios)
        return 0

    @property
    def percentual_eficiencia(self):
        if self.quantidade_esperada > 0:
            return (self.quantidade_produzida / self.quantidade_esperada) * 100
        return 0

    @property
    def custo_mao_obra(self):
        """Calcula o custo total da mão de obra para esta produção"""
        if self.horas_trabalhadas > 0 and len(self.funcionarios) > 0:
            custo_total = 0
            for funcionario in self.funcionarios:
                custo_total += funcionario.custo_hora * self.horas_trabalhadas
            return custo_total
        return 0

    def to_dict(self):
        return {
            'id': self.id,
            'data_inicio': self.data_inicio.isoformat() if self.data_inicio else None,
            'ordem_producao': self.ordem_producao,
            'horario_inicio': self.horario_inicio.isoformat() if self.horario_inicio else None,
            'horario_fim': self.horario_fim.isoformat() if self.horario_fim else None,
            'produto_id': self.produto_id,
            'produto_nome': self.produto.nome if self.produto else None,
            'produto_categoria': self.produto.categoria if self.produto else None,
            'user_id': self.user_id,
            'user_nome': self.user.nome if self.user else None,
            'funcionarios': [{'id': f.id, 'nome': f.nome, 'custo_hora': f.custo_hora} for f in self.funcionarios],
            'quantidade_produzida': self.quantidade_produzida,
            'quantidade_esperada': self.quantidade_esperada,
            'percentual_eficiencia': self.percentual_eficiencia,
            'custo_mao_obra': self.custo_mao_obra,
            'horas_trabalhadas': self.horas_trabalhadas,
            'status': self.status,
            'observacoes': self.observacoes,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

