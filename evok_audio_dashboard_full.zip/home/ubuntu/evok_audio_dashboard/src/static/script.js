// Global variables
let currentUser = null;
let produtos = [];
let funcionarios = [];
let categorias = [];
let departamentos = [];

// DOM Elements
const loginScreen = document.getElementById('login-screen');
const mainPanel = document.getElementById('main-panel');
const loginForm = document.getElementById('login-form');
const loginError = document.getElementById('login-error');
const userNameSpan = document.getElementById('user-name');
const logoutBtn = document.getElementById('logout-btn');
const modalOverlay = document.getElementById('modal-overlay');
const modalContent = document.getElementById('modal-content');

// Initialize app
document.addEventListener('DOMContentLoaded', function() {
    checkSession();
    setupEventListeners();
});

// Check if user is already logged in
async function checkSession() {
    try {
        const response = await fetch('/api/check-session');
        const data = await response.json();
        
        if (data.authenticated) {
            currentUser = data.user;
            showMainPanel();
        } else {
            showLoginScreen();
        }
    } catch (error) {
        console.error('Error checking session:', error);
        showLoginScreen();
    }
}

// Setup event listeners
function setupEventListeners() {
    // Login form
    loginForm.addEventListener('submit', handleLogin);
    
    // Logout button
    logoutBtn.addEventListener('click', handleLogout);
    
    // Navigation
    document.querySelectorAll('.nav-link').forEach(link => {
        link.addEventListener('click', handleNavigation);
    });
    
    // Modal close - REMOVIDO o event listener que causava fechamento automático
    // modalOverlay.addEventListener('click', function(e) {
    //     if (e.target === modalOverlay) {
    //         closeModal();
    //     }
    // });
    
    // Add buttons
    document.getElementById('add-produto-btn').addEventListener('click', () => showProdutoModal());
    document.getElementById('add-funcionario-btn').addEventListener('click', () => showFuncionarioModal());
    document.getElementById('add-producao-btn').addEventListener('click', () => showProducaoModal());
    
    // Filter buttons
    document.getElementById('dashboard-filter-btn').addEventListener('click', loadDashboardMetrics);
    document.getElementById('gerar-relatorio-btn').addEventListener('click', gerarRelatorio);
}

// Login handling
async function handleLogin(e) {
    e.preventDefault();
    
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    
    try {
        const response = await fetch('/api/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ username, password })
        });
        
        const data = await response.json();
        
        if (response.ok) {
            currentUser = data.user;
            showMainPanel();
        } else {
            showError(data.error);
        }
    } catch (error) {
        showError('Erro ao fazer login');
    }
}

// Logout handling
async function handleLogout() {
    try {
        await fetch('/api/logout', { method: 'POST' });
        currentUser = null;
        showLoginScreen();
    } catch (error) {
        console.error('Error logging out:', error);
    }
}

// Show/hide screens
function showLoginScreen() {
    loginScreen.style.display = 'flex';
    mainPanel.style.display = 'none';
    document.getElementById('username').value = '';
    document.getElementById('password').value = '';
    hideError();
}

function showMainPanel() {
    loginScreen.style.display = 'none';
    mainPanel.style.display = 'grid';
    userNameSpan.textContent = currentUser.nome;
    
    // Show/hide admin menu
    const configMenu = document.getElementById('config-menu');
    if (currentUser.is_admin) {
        configMenu.style.display = 'block';
    } else {
        configMenu.style.display = 'none';
    }
    
    // Load initial data
    loadInitialData();
    showTab('dashboard');
}

// Error handling
function showError(message) {
    loginError.textContent = message;
    loginError.style.display = 'block';
}

function hideError() {
    loginError.style.display = 'none';
}

// Navigation handling
function handleNavigation(e) {
    e.preventDefault();
    const tabName = e.target.closest('.nav-link').dataset.tab;
    showTab(tabName);
}

function showTab(tabName) {
    // Update navigation
    document.querySelectorAll('.nav-link').forEach(link => {
        link.classList.remove('active');
    });
    document.querySelector(`[data-tab="${tabName}"]`).classList.add('active');
    
    // Update content
    document.querySelectorAll('.tab-content').forEach(tab => {
        tab.classList.remove('active');
    });
    document.getElementById(`${tabName}-tab`).classList.add('active');
    
    // Load tab-specific data
    switch(tabName) {
        case 'dashboard':
            loadDashboardMetrics();
            break;
        case 'produtos':
            loadProdutos();
            break;
        case 'funcionarios':
            loadFuncionarios();
            break;
        case 'producao':
            loadProducao();
            break;
        case 'relatorios':
            loadRelatorioFilters();
            break;
        case 'configuracoes':
            if (currentUser.is_admin) {
                loadConfiguracoes();
            }
            break;
    }
}

// Load initial data
async function loadInitialData() {
    try {
        // Load produtos for filters
        const produtosResponse = await fetch('/api/produtos');
        if (produtosResponse.ok) {
            produtos = await produtosResponse.json();
            updateProdutoFilters();
        }
        
        // Load categorias
        const categoriasResponse = await fetch('/api/categorias');
        if (categoriasResponse.ok) {
            categorias = await categoriasResponse.json();
            updateCategoriaFilters();
        }
    } catch (error) {
        console.error('Error loading initial data:', error);
    }
}

// Update filter dropdowns
function updateProdutoFilters() {
    const selects = document.querySelectorAll('select[id$="-produto"]');
    selects.forEach(select => {
        const currentValue = select.value;
        select.innerHTML = '<option value="">Todos os Produtos</option>';
        produtos.forEach(produto => {
            const option = document.createElement('option');
            option.value = produto.id;
            option.textContent = produto.nome;
            select.appendChild(option);
        });
        select.value = currentValue;
    });
}

function updateCategoriaFilters() {
    const selects = document.querySelectorAll('select[id$="-categoria"]');
    selects.forEach(select => {
        const currentValue = select.value;
        select.innerHTML = '<option value="">Todas as Categorias</option>';
        categorias.forEach(categoria => {
            const option = document.createElement('option');
            option.value = categoria;
            option.textContent = categoria;
            select.appendChild(option);
        });
        select.value = currentValue;
    });
}

// Dashboard functions
async function loadDashboardMetrics() {
    try {
        const params = new URLSearchParams();
        
        const dataInicio = document.getElementById('dashboard-data-inicio').value;
        const dataFim = document.getElementById('dashboard-data-fim').value;
        const categoria = document.getElementById('dashboard-categoria').value;
        const produto = document.getElementById('dashboard-produto').value;
        
        if (dataInicio) params.append('data_inicio', dataInicio);
        if (dataFim) params.append('data_fim', dataFim);
        if (categoria) params.append('categoria', categoria);
        if (produto) params.append('produto_id', produto);
        
        const response = await fetch(`/api/dashboard/metricas?${params}`);
        const data = await response.json();
        
        if (response.ok) {
            updateDashboardMetrics(data);
        }
    } catch (error) {
        console.error('Error loading dashboard metrics:', error);
    }
}

function updateDashboardMetrics(data) {
    document.getElementById('categoria-mais-produzida').textContent = 
        `${data.categoria_mais_produzida.nome} (${data.categoria_mais_produzida.quantidade.toFixed(1)})`;
    
    document.getElementById('departamento-mais-produziu').textContent = 
        `${data.departamento_mais_produziu.nome} (${data.departamento_mais_produziu.quantidade.toFixed(1)})`;
    
    document.getElementById('produto-mais-produzido').textContent = 
        `${data.produto_mais_produzido.nome} (${data.produto_mais_produzido.quantidade.toFixed(1)})`;
    
    document.getElementById('departamento-melhor-resultado').textContent = 
        `${data.departamento_melhor_resultado.nome} (${data.departamento_melhor_resultado.eficiencia.toFixed(1)}%)`;
    
    // Update charts (simplified version)
    updateChart('custo-produto-chart', data.custo_mao_obra_produto);
    updateChart('custo-categoria-chart', data.custo_mao_obra_categoria);
}

function updateChart(containerId, data) {
    const container = document.getElementById(containerId);
    container.innerHTML = '';
    
    if (Object.keys(data).length === 0) {
        container.innerHTML = '<p>Nenhum dado disponível</p>';
        return;
    }
    
    const maxValue = Math.max(...Object.values(data));
    
    Object.entries(data).forEach(([key, value]) => {
        const bar = document.createElement('div');
        bar.style.cssText = `
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: #2a2a2a;
            margin: 5px 0;
            padding: 10px;
            border-radius: 5px;
            position: relative;
        `;
        
        const barFill = document.createElement('div');
        barFill.style.cssText = `
            position: absolute;
            left: 0;
            top: 0;
            height: 100%;
            background: linear-gradient(90deg, #00ff00, #00cc00);
            border-radius: 5px;
            width: ${(value / maxValue) * 100}%;
            opacity: 0.3;
        `;
        
        bar.innerHTML = `
            <span style="position: relative; z-index: 1;">${key}</span>
            <span style="position: relative; z-index: 1;">R$ ${value.toFixed(2)}</span>
        `;
        
        bar.appendChild(barFill);
        container.appendChild(bar);
    });
}

// Produtos functions
async function loadProdutos() {
    try {
        const response = await fetch('/api/produtos');
        const data = await response.json();
        
        if (response.ok) {
            produtos = data;
            updateProdutosTable(data);
            updateProdutoFilters();
        }
    } catch (error) {
        console.error('Error loading produtos:', error);
    }
}

function updateProdutosTable(produtos) {
    const tbody = document.querySelector('#produtos-table tbody');
    tbody.innerHTML = '';
    
    produtos.forEach(produto => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${produto.nome}</td>
            <td>${produto.categoria}</td>
            <td>${produto.qtd_produzida_por_hora_funcionario}</td>
            <td>
                <button class="action-btn edit" onclick="editProduto(${produto.id})">
                    <i class="fas fa-edit"></i>
                </button>
                <button class="action-btn delete" onclick="deleteProduto(${produto.id})">
                    <i class="fas fa-trash"></i>
                </button>
            </td>
        `;
        tbody.appendChild(row);
    });
}

function showProdutoModal(produto = null) {
    const isEdit = produto !== null;
    
    modalContent.innerHTML = `
        <div class="modal-header">
            <h3>${isEdit ? 'Editar' : 'Novo'} Produto</h3>
            <button class="close-btn" onclick="closeModal()">&times;</button>
        </div>
        <form id="produto-form">
            <div class="form-group">
                <label for="produto-nome">Nome do Produto</label>
                <input type="text" id="produto-nome" value="${produto ? produto.nome : ''}" required>
            </div>
            <div class="form-group">
                <label for="produto-categoria">Categoria</label>
                <input type="text" id="produto-categoria" value="${produto ? produto.categoria : ''}" required>
            </div>
            <div class="form-group">
                <label for="produto-qtd">Quantidade Produzida por Hora por Funcionário</label>
                <input type="number" step="0.01" id="produto-qtd" value="${produto ? produto.qtd_produzida_por_hora_funcionario : ''}" required>
            </div>
            <div class="form-actions">
                <button type="button" class="btn-secondary" onclick="closeModal()">Cancelar</button>
                <button type="submit" class="btn-primary">${isEdit ? 'Atualizar' : 'Criar'}</button>
            </div>
        </form>
    `;
    
    document.getElementById('produto-form').addEventListener('submit', (e) => {
        e.preventDefault();
        saveProduto(produto ? produto.id : null);
    });
    
    modalOverlay.style.display = 'flex';
}

async function saveProduto(id = null) {
    const nome = document.getElementById('produto-nome').value;
    const categoria = document.getElementById('produto-categoria').value;
    const qtd = parseFloat(document.getElementById('produto-qtd').value);
    
    const data = {
        nome,
        categoria,
        qtd_produzida_por_hora_funcionario: qtd
    };
    
    try {
        const url = id ? `/api/produtos/${id}` : '/api/produtos';
        const method = id ? 'PUT' : 'POST';
        
        const response = await fetch(url, {
            method,
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        });
        
        const result = await response.json();
        
        if (response.ok) {
            closeModal();
            loadProdutos();
            loadInitialData(); // Reload filters
        } else {
            alert(result.error);
        }
    } catch (error) {
        console.error('Error saving produto:', error);
        alert('Erro ao salvar produto');
    }
}

function editProduto(id) {
    const produto = produtos.find(p => p.id === id);
    if (produto) {
        showProdutoModal(produto);
    }
}

async function deleteProduto(id) {
    if (!confirm('Tem certeza que deseja deletar este produto?')) {
        return;
    }
    
    try {
        const response = await fetch(`/api/produtos/${id}`, {
            method: 'DELETE'
        });
        
        if (response.ok) {
            loadProdutos();
            loadInitialData(); // Reload filters
        } else {
            const data = await response.json();
            alert(data.error);
        }
    } catch (error) {
        console.error('Error deleting produto:', error);
        alert('Erro ao deletar produto');
    }
}

// Funcionários functions
async function loadFuncionarios() {
    try {
        const response = await fetch('/api/funcionarios');
        const data = await response.json();
        
        if (response.ok) {
            funcionarios = data;
            updateFuncionariosTable(data);
        } else if (response.status === 403) {
            document.querySelector('#funcionarios-table tbody').innerHTML = 
                '<tr><td colspan="6" style="text-align: center; color: #ff4444;">Sem permissão para visualizar funcionários</td></tr>';
        }
    } catch (error) {
        console.error('Error loading funcionarios:', error);
    }
}

function updateFuncionariosTable(funcionarios) {
    const tbody = document.querySelector('#funcionarios-table tbody');
    tbody.innerHTML = '';
    
    funcionarios.forEach(funcionario => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${funcionario.nome}</td>
            <td>${funcionario.departamento}</td>
            <td>${funcionario.funcao}</td>
            <td>R$ ${funcionario.salario.toFixed(2)}</td>
            <td>R$ ${funcionario.custo_hora.toFixed(2)}</td>
            <td>
                <button class="action-btn edit" onclick="editFuncionario(${funcionario.id})">
                    <i class="fas fa-edit"></i>
                </button>
                ${currentUser.is_admin ? `
                <button class="action-btn delete" onclick="deleteFuncionario(${funcionario.id})">
                    <i class="fas fa-trash"></i>
                </button>
                ` : ''}
            </td>
        `;
        tbody.appendChild(row);
    });
}

function showFuncionarioModal(funcionario = null) {
    const isEdit = funcionario !== null;
    
    modalContent.innerHTML = `
        <div class="modal-header">
            <h3>${isEdit ? 'Editar' : 'Novo'} Funcionário</h3>
            <button class="close-btn" onclick="closeModal()">&times;</button>
        </div>
        <form id="funcionario-form">
            <div class="form-group">
                <label for="funcionario-username">Usuário</label>
                <input type="text" id="funcionario-username" value="${funcionario ? funcionario.username : ''}" ${isEdit ? 'readonly' : ''} required>
            </div>
            <div class="form-group">
                <label for="funcionario-password">Senha</label>
                <input type="password" id="funcionario-password" ${isEdit ? '' : 'required'}>
                ${isEdit ? '<small style="color: #888;">Deixe em branco para manter a senha atual</small>' : ''}
            </div>
            <div class="form-group">
                <label for="funcionario-nome">Nome</label>
                <input type="text" id="funcionario-nome" value="${funcionario ? funcionario.nome : ''}" required>
            </div>
            <div class="form-group">
                <label for="funcionario-departamento">Departamento</label>
                <input type="text" id="funcionario-departamento" value="${funcionario ? funcionario.departamento : ''}" required>
            </div>
            <div class="form-group">
                <label for="funcionario-funcao">Função</label>
                <input type="text" id="funcionario-funcao" value="${funcionario ? funcionario.funcao : ''}" required>
            </div>
            <div class="form-group">
                <label for="funcionario-salario">Salário</label>
                <input type="number" step="0.01" id="funcionario-salario" value="${funcionario ? funcionario.salario : ''}" required>
            </div>
            ${currentUser.is_admin ? `
            <div class="form-group">
                <div class="checkbox-container">
                    <input type="checkbox" id="funcionario-can-view" ${funcionario && funcionario.pode_ver_funcionarios ? 'checked' : ''}>
                    <label for="funcionario-can-view">Pode ver funcionários</label>
                </div>
            </div>
            <div class="form-group">
                <div class="checkbox-container">
                    <input type="checkbox" id="funcionario-is-admin" ${funcionario && funcionario.is_admin ? 'checked' : ''}>
                    <label for="funcionario-is-admin">Administrador</label>
                </div>
            </div>
            ` : ''}
            <div class="form-actions">
                <button type="button" class="btn-secondary" onclick="closeModal()">Cancelar</button>
                <button type="submit" class="btn-primary">${isEdit ? 'Atualizar' : 'Criar'}</button>
            </div>
        </form>
    `;
    
    document.getElementById('funcionario-form').addEventListener('submit', (e) => {
        e.preventDefault();
        saveFuncionario(funcionario ? funcionario.id : null);
    });
    
    modalOverlay.style.display = 'flex';
}

async function saveFuncionario(id = null) {
    const username = document.getElementById('funcionario-username').value;
    const password = document.getElementById('funcionario-password').value;
    const nome = document.getElementById('funcionario-nome').value;
    const departamento = document.getElementById('funcionario-departamento').value;
    const funcao = document.getElementById('funcionario-funcao').value;
    const salario = parseFloat(document.getElementById('funcionario-salario').value);
    
    const data = {
        username,
        nome,
        departamento,
        funcao,
        salario
    };
    
    if (password) {
        data.password = password;
    }
    
    if (currentUser.is_admin) {
        data.pode_ver_funcionarios = document.getElementById('funcionario-can-view').checked;
        data.is_admin = document.getElementById('funcionario-is-admin').checked;
    }
    
    try {
        let url, method;
        
        if (id) {
            url = `/api/funcionarios/${id}`;
            method = 'PUT';
        } else {
            url = '/api/register';
            method = 'POST';
        }
        
        const response = await fetch(url, {
            method,
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        });
        
        const result = await response.json();
        
        if (response.ok) {
            closeModal();
            loadFuncionarios();
        } else {
            alert(result.error);
        }
    } catch (error) {
        console.error('Error saving funcionario:', error);
        alert('Erro ao salvar funcionário');
    }
}

function editFuncionario(id) {
    const funcionario = funcionarios.find(f => f.id === id);
    if (funcionario) {
        showFuncionarioModal(funcionario);
    }
}

async function deleteFuncionario(id) {
    if (!confirm('Tem certeza que deseja deletar este funcionário?')) {
        return;
    }
    
    try {
        const response = await fetch(`/api/funcionarios/${id}`, {
            method: 'DELETE'
        });
        
        if (response.ok) {
            loadFuncionarios();
        } else {
            const data = await response.json();
            alert(data.error);
        }
    } catch (error) {
        console.error('Error deleting funcionario:', error);
        alert('Erro ao deletar funcionário');
    }
}

// Produção functions
async function loadProducao() {
    try {
        // Load pending productions
        const pendentesResponse = await fetch('/api/producao/pendentes');
        if (pendentesResponse.ok) {
            const pendentes = await pendentesResponse.json();
            updateProducaoPendenteTable(pendentes);
        }
        
        // Load production history
        const historicoResponse = await fetch('/api/producao');
        if (historicoResponse.ok) {
            const historico = await historicoResponse.json();
            updateProducaoHistoricoTable(historico);
        }
    } catch (error) {
        console.error('Error loading producao:', error);
    }
}

function updateProducaoPendenteTable(producoes) {
    const tbody = document.querySelector('#producao-pendente-table tbody');
    tbody.innerHTML = '';
    
    producoes.forEach(producao => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${producao.ordem_producao}</td>
            <td>${producao.produto_nome}</td>
            <td>${new Date(producao.horario_inicio).toLocaleString('pt-BR')}</td>
            <td>${producao.quantidade_produzida}</td>
            <td>
                <button class="action-btn finalize" onclick="finalizarProducao(${producao.id})">
                    <i class="fas fa-check"></i> Finalizar
                </button>
                <button class="action-btn edit" onclick="editProducao(${producao.id})">
                    <i class="fas fa-edit"></i>
                </button>
            </td>
        `;
        tbody.appendChild(row);
    });
}

function updateProducaoHistoricoTable(producoes) {
    const tbody = document.querySelector('#producao-historico-table tbody');
    tbody.innerHTML = '';
    
    producoes.forEach(producao => {
        const eficienciaClass = producao.percentual_eficiencia >= 100 ? 'efficiency-good' : 
                               producao.percentual_eficiencia >= 80 ? 'efficiency-warning' : 'efficiency-bad';
        
        const funcionariosNomes = producao.funcionarios ? 
            producao.funcionarios.map(f => f.nome).join(', ') : '-';
        
        const custoMaoObra = producao.custo_mao_obra ? 
            `R$ ${producao.custo_mao_obra.toFixed(2)}` : 'R$ 0,00';
        
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${producao.ordem_producao}</td>
            <td>${producao.produto_nome}</td>
            <td>${funcionariosNomes}</td>
            <td>${new Date(producao.horario_inicio).toLocaleString('pt-BR')}</td>
            <td>${producao.horario_fim ? new Date(producao.horario_fim).toLocaleString('pt-BR') : '-'}</td>
            <td>${producao.quantidade_produzida}</td>
            <td class="${eficienciaClass}">${producao.percentual_eficiencia.toFixed(1)}%</td>
            <td>${custoMaoObra}</td>
            <td><span class="status-badge status-${producao.status}">${producao.status}</span></td>
        `;
        tbody.appendChild(row);
    });
}

function showProducaoModal(producao = null) {
    const isEdit = producao !== null;
    
    modalContent.innerHTML = `
        <div class="modal-header">
            <h3>${isEdit ? 'Editar' : 'Nova'} Produção</h3>
            <button class="close-btn" onclick="closeModal()">&times;</button>
        </div>
        <form id="producao-form">
            <div class="form-group">
                <label for="producao-data">Data de Início</label>
                <input type="date" id="producao-data" value="${producao ? producao.data_inicio : new Date().toISOString().split('T')[0]}" required>
            </div>
            <div class="form-group">
                <label for="producao-ordem">Ordem de Produção</label>
                <input type="text" id="producao-ordem" value="${producao ? producao.ordem_producao : ''}" ${isEdit ? 'readonly' : ''} required>
            </div>
            <div class="form-group">
                <label for="producao-horario">Horário de Início</label>
                <input type="datetime-local" id="producao-horario" value="${producao ? producao.horario_inicio.slice(0, 16) : new Date().toISOString().slice(0, 16)}" required>
            </div>
            <div class="form-group">
                <label for="producao-produto">Produto</label>
                <select id="producao-produto" required>
                    <option value="">Selecione um produto</option>
                    ${produtos.map(p => `<option value="${p.id}" ${producao && producao.produto_id === p.id ? 'selected' : ''}>${p.nome}</option>`).join('')}
                </select>
            </div>
            <div class="form-group">
                <label for="producao-funcionarios">Funcionários</label>
                <div class="funcionarios-selection" id="funcionarios-selection">
                    ${funcionarios.map(f => `
                        <div class="funcionario-checkbox">
                            <input type="checkbox" id="func-${f.id}" value="${f.id}" 
                                ${producao && producao.funcionarios && producao.funcionarios.some(pf => pf.id === f.id) ? 'checked' : ''}>
                            <label for="func-${f.id}">${f.nome} (${f.departamento})</label>
                        </div>
                    `).join('')}
                </div>
                <small class="form-help">Selecione os funcionários que trabalharão nesta produção</small>
            </div>
            <div class="form-group">
                <label for="producao-quantidade">Quantidade Produzida</label>
                <input type="number" step="0.01" id="producao-quantidade" value="${producao ? producao.quantidade_produzida : ''}" required>
            </div>
            <div class="form-group">
                <label for="producao-observacoes">Observações</label>
                <textarea id="producao-observacoes">${producao ? producao.observacoes || '' : ''}</textarea>
            </div>
            <div class="form-actions">
                <button type="button" class="btn-secondary" onclick="closeModal()">Cancelar</button>
                <button type="submit" class="btn-primary">${isEdit ? 'Atualizar' : 'Iniciar'}</button>
            </div>
        </form>
    `;
    
    document.getElementById('producao-form').addEventListener('submit', (e) => {
        e.preventDefault();
        saveProducao(producao ? producao.id : null);
    });
    
    modalOverlay.style.display = 'flex';
}

async function saveProducao(id = null) {
    const dataInicio = document.getElementById('producao-data').value;
    const ordemProducao = document.getElementById('producao-ordem').value;
    const horarioInicio = document.getElementById('producao-horario').value;
    const produtoId = parseInt(document.getElementById('producao-produto').value);
    const quantidade = parseFloat(document.getElementById('producao-quantidade').value);
    const observacoes = document.getElementById('producao-observacoes').value;
    
    // Coletar funcionários selecionados
    const funcionariosCheckboxes = document.querySelectorAll('#funcionarios-selection input[type="checkbox"]:checked');
    const funcionariosIds = Array.from(funcionariosCheckboxes).map(cb => parseInt(cb.value));
    
    if (funcionariosIds.length === 0) {
        alert('Selecione pelo menos um funcionário para a produção');
        return;
    }
    
    const data = {
        data_inicio: dataInicio,
        ordem_producao: ordemProducao,
        horario_inicio: horarioInicio,
        produto_id: produtoId,
        quantidade_produzida: quantidade,
        funcionarios_ids: funcionariosIds,
        observacoes
    };
    
    try {
        const url = id ? `/api/producao/${id}` : '/api/producao';
        const method = id ? 'PUT' : 'POST';
        
        const response = await fetch(url, {
            method,
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        });
        
        const result = await response.json();
        
        if (response.ok) {
            closeModal();
            loadProducao();
        } else {
            alert(result.error);
        }
    } catch (error) {
        console.error('Error saving producao:', error);
        alert('Erro ao salvar produção');
    }
}

async function finalizarProducao(id) {
    if (!confirm('Tem certeza que deseja finalizar esta produção?')) {
        return;
    }
    
    try {
        const response = await fetch(`/api/producao/${id}/finalizar`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({})
        });
        
        const result = await response.json();
        
        if (response.ok) {
            loadProducao();
            alert(`Produção finalizada! Eficiência: ${result.producao.percentual_eficiencia.toFixed(1)}%`);
        } else {
            alert(result.error);
        }
    } catch (error) {
        console.error('Error finalizing producao:', error);
        alert('Erro ao finalizar produção');
    }
}

function editProducao(id) {
    // For simplicity, we'll just allow editing quantity and observations
    const quantidade = prompt('Nova quantidade produzida:');
    if (quantidade === null) return;
    
    const observacoes = prompt('Observações:') || '';
    
    fetch(`/api/producao/${id}`, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            quantidade_produzida: parseFloat(quantidade),
            observacoes
        })
    })
    .then(response => response.json())
    .then(result => {
        if (result.message) {
            loadProducao();
        } else {
            alert(result.error);
        }
    })
    .catch(error => {
        console.error('Error editing producao:', error);
        alert('Erro ao editar produção');
    });
}

// Relatórios functions
function loadRelatorioFilters() {
    updateCategoriaFilters();
    updateProdutoFilters();
}

async function gerarRelatorio() {
    try {
        const params = new URLSearchParams();
        
        const dataInicio = document.getElementById('relatorio-data-inicio').value;
        const dataFim = document.getElementById('relatorio-data-fim').value;
        const categoria = document.getElementById('relatorio-categoria').value;
        const produto = document.getElementById('relatorio-produto').value;
        
        if (dataInicio) params.append('data_inicio', dataInicio);
        if (dataFim) params.append('data_fim', dataFim);
        if (categoria) params.append('categoria', categoria);
        if (produto) params.append('produto_id', produto);
        
        const response = await fetch(`/api/relatorios/producao?${params}`);
        const data = await response.json();
        
        if (response.ok) {
            displayRelatorio(data);
        }
    } catch (error) {
        console.error('Error generating report:', error);
    }
}

function displayRelatorio(data) {
    const container = document.getElementById('relatorio-content');
    
    container.innerHTML = `
        <div class="relatorio-header">
            <h3>Relatório de Produção</h3>
            <button class="btn-primary" onclick="imprimirRelatorio()">
                <i class="fas fa-print"></i> Imprimir Relatório
            </button>
        </div>
        
        <div class="relatorio-stats">
            <div class="stat-item">
                <h4>Total de Produções</h4>
                <p>${data.estatisticas.total_producoes}</p>
            </div>
            <div class="stat-item">
                <h4>Total de Horas</h4>
                <p>${data.estatisticas.total_horas.toFixed(1)}</p>
            </div>
            <div class="stat-item">
                <h4>Quantidade Produzida</h4>
                <p>${data.estatisticas.total_quantidade_produzida.toFixed(1)}</p>
            </div>
            <div class="stat-item">
                <h4>Eficiência Média</h4>
                <p>${data.estatisticas.eficiencia_media.toFixed(1)}%</p>
            </div>
        </div>
        
        <h4>Eficiência por Departamento</h4>
        <div class="table-container">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Departamento</th>
                        <th>Produções</th>
                        <th>Horas</th>
                        <th>Produzido</th>
                        <th>Esperado</th>
                        <th>Eficiência</th>
                    </tr>
                </thead>
                <tbody>
                    ${Object.entries(data.estatisticas.departamentos).map(([dept, stats]) => `
                        <tr>
                            <td>${dept}</td>
                            <td>${stats.total_producoes}</td>
                            <td>${stats.total_horas.toFixed(1)}</td>
                            <td>${stats.total_quantidade_produzida.toFixed(1)}</td>
                            <td>${stats.total_quantidade_esperada.toFixed(1)}</td>
                            <td class="${stats.eficiencia_media >= 100 ? 'efficiency-good' : stats.eficiencia_media >= 80 ? 'efficiency-warning' : 'efficiency-bad'}">${stats.eficiencia_media.toFixed(1)}%</td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        </div>
        
        <h4>Detalhes das Produções</h4>
        <div class="table-container">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Ordem</th>
                        <th>Produto</th>
                        <th>Categoria</th>
                        <th>Funcionário</th>
                        <th>Departamento</th>
                        <th>Data</th>
                        <th>Horas</th>
                        <th>Produzido</th>
                        <th>Esperado</th>
                        <th>Eficiência</th>
                    </tr>
                </thead>
                <tbody>
                    ${data.producoes.map(p => `
                        <tr>
                            <td>${p.ordem_producao}</td>
                            <td>${p.produto_nome}</td>
                            <td>${p.produto_categoria}</td>
                            <td>${p.user_nome}</td>
                            <td>${p.user_departamento}</td>
                            <td>${new Date(p.data_inicio).toLocaleDateString('pt-BR')}</td>
                            <td>${p.horas_trabalhadas.toFixed(1)}</td>
                            <td>${p.quantidade_produzida.toFixed(1)}</td>
                            <td>${p.quantidade_esperada.toFixed(1)}</td>
                            <td class="${p.percentual_eficiencia >= 100 ? 'efficiency-good' : p.percentual_eficiencia >= 80 ? 'efficiency-warning' : 'efficiency-bad'}">${p.percentual_eficiencia.toFixed(1)}%</td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        </div>
    `;
}

// Função de impressão do relatório
function imprimirRelatorio() {
    // Criar uma nova janela para impressão
    const printWindow = window.open('', '_blank');
    
    // Obter o conteúdo do relatório
    const relatorioContent = document.getElementById('relatorio-content');
    
    // HTML completo para impressão
    const printHTML = `
        <!DOCTYPE html>
        <html>
        <head>
            <title>Relatório de Produção - Evok Audio</title>
            <style>
                * {
                    margin: 0;
                    padding: 0;
                    box-sizing: border-box;
                }
                
                body {
                    font-family: Arial, sans-serif;
                    color: #333;
                    line-height: 1.4;
                    padding: 20px;
                }
                
                .print-header {
                    text-align: center;
                    margin-bottom: 30px;
                    border-bottom: 2px solid #00ff00;
                    padding-bottom: 20px;
                }
                
                .print-header h1 {
                    color: #00ff00;
                    font-size: 24px;
                    margin-bottom: 10px;
                }
                
                .print-header p {
                    color: #666;
                    font-size: 14px;
                }
                
                .relatorio-header {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    margin-bottom: 20px;
                }
                
                .relatorio-header button {
                    display: none; /* Ocultar botão na impressão */
                }
                
                h3, h4 {
                    color: #00ff00;
                    margin: 20px 0 10px 0;
                }
                
                .relatorio-stats {
                    display: grid;
                    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
                    gap: 15px;
                    margin-bottom: 30px;
                }
                
                .stat-item {
                    background: #f8f9fa;
                    padding: 15px;
                    border-radius: 5px;
                    border-left: 4px solid #00ff00;
                }
                
                .stat-item h4 {
                    font-size: 14px;
                    color: #666;
                    margin-bottom: 5px;
                }
                
                .stat-item p {
                    font-size: 18px;
                    font-weight: bold;
                    color: #333;
                }
                
                .table-container {
                    margin-bottom: 30px;
                    overflow: visible;
                }
                
                table {
                    width: 100%;
                    border-collapse: collapse;
                    font-size: 12px;
                }
                
                th, td {
                    border: 1px solid #ddd;
                    padding: 8px;
                    text-align: left;
                }
                
                th {
                    background-color: #00ff00;
                    color: white;
                    font-weight: bold;
                }
                
                tr:nth-child(even) {
                    background-color: #f9f9f9;
                }
                
                .efficiency-good {
                    color: #28a745;
                    font-weight: bold;
                }
                
                .efficiency-warning {
                    color: #ffc107;
                    font-weight: bold;
                }
                
                .efficiency-bad {
                    color: #dc3545;
                    font-weight: bold;
                }
                
                .print-footer {
                    margin-top: 40px;
                    text-align: center;
                    font-size: 12px;
                    color: #666;
                    border-top: 1px solid #ddd;
                    padding-top: 20px;
                }
                
                @media print {
                    body {
                        padding: 0;
                    }
                    
                    .relatorio-header button {
                        display: none !important;
                    }
                    
                    table {
                        page-break-inside: avoid;
                    }
                    
                    tr {
                        page-break-inside: avoid;
                    }
                }
            </style>
        </head>
        <body>
            <div class="print-header">
                <h1>EVOK AUDIO</h1>
                <p>Relatório de Produção - Gerado em ${new Date().toLocaleDateString('pt-BR')} às ${new Date().toLocaleTimeString('pt-BR')}</p>
            </div>
            
            ${relatorioContent.innerHTML}
            
            <div class="print-footer">
                <p>Este relatório foi gerado automaticamente pelo Sistema de Controle de Produção Evok Audio</p>
            </div>
        </body>
        </html>
    `;
    
    // Escrever o HTML na nova janela
    printWindow.document.write(printHTML);
    printWindow.document.close();
    
    // Aguardar o carregamento e imprimir
    printWindow.onload = function() {
        printWindow.print();
        printWindow.close();
    };
}

// Configurações functions
async function loadConfiguracoes() {
    try {
        const response = await fetch('/api/configuracoes/usuarios');
        const data = await response.json();
        
        if (response.ok) {
            updateConfigUsuariosTable(data);
        }
    } catch (error) {
        console.error('Error loading configuracoes:', error);
    }
}

function updateConfigUsuariosTable(usuarios) {
    const tbody = document.querySelector('#config-usuarios-table tbody');
    tbody.innerHTML = '';
    
    usuarios.forEach(usuario => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${usuario.username}</td>
            <td>${usuario.nome}</td>
            <td>${usuario.departamento}</td>
            <td>
                <div class="checkbox-container">
                    <input type="checkbox" ${usuario.pode_ver_funcionarios ? 'checked' : ''} 
                           onchange="updatePermissao(${usuario.id}, 'pode_ver_funcionarios', this.checked)">
                </div>
            </td>
            <td>
                <div class="checkbox-container">
                    <input type="checkbox" ${usuario.is_admin ? 'checked' : ''} 
                           onchange="updatePermissao(${usuario.id}, 'is_admin', this.checked)">
                </div>
            </td>
            <td>
                <button class="action-btn edit" onclick="editFuncionario(${usuario.id})">
                    <i class="fas fa-edit"></i>
                </button>
            </td>
        `;
        tbody.appendChild(row);
    });
}

async function updatePermissao(userId, permission, value) {
    try {
        const response = await fetch(`/api/configuracoes/usuarios/${userId}/permissoes`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                [permission]: value
            })
        });
        
        const result = await response.json();
        
        if (!response.ok) {
            alert(result.error);
            loadConfiguracoes(); // Reload to reset checkboxes
        }
    } catch (error) {
        console.error('Error updating permission:', error);
        alert('Erro ao atualizar permissão');
        loadConfiguracoes(); // Reload to reset checkboxes
    }
}

// Modal functions
function closeModal() {
    modalOverlay.style.display = 'none';
    modalContent.innerHTML = '';
}

// Make functions globally available
window.editProduto = editProduto;
window.deleteProduto = deleteProduto;
window.editFuncionario = editFuncionario;
window.deleteFuncionario = deleteFuncionario;
window.finalizarProducao = finalizarProducao;
window.editProducao = editProducao;
window.updatePermissao = updatePermissao;
window.closeModal = closeModal;
window.imprimirRelatorio = imprimirRelatorio;

