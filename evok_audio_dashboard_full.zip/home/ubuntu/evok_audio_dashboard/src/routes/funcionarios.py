from flask import Blueprint, request, jsonify, session
from src.models.user import db, User
from src.routes.auth import require_auth

funcionarios_bp = Blueprint('funcionarios', __name__)

@funcionarios_bp.route('/funcionarios', methods=['GET'])
@require_auth
def get_funcionarios():
    try:
        # Verificar permissão para ver funcionários
        current_user = User.query.get(session['user_id'])
        if not current_user.pode_ver_funcionarios and not current_user.is_admin:
            return jsonify({'error': 'Sem permissão para visualizar funcionários'}), 403

        funcionarios = User.query.all()
        return jsonify([funcionario.to_dict() for funcionario in funcionarios]), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@funcionarios_bp.route('/funcionarios/<int:funcionario_id>', methods=['GET'])
@require_auth
def get_funcionario(funcionario_id):
    try:
        current_user = User.query.get(session['user_id'])
        
        # Admin pode ver qualquer funcionário, outros só podem ver a si mesmos
        if not current_user.is_admin and current_user.id != funcionario_id:
            if not current_user.pode_ver_funcionarios:
                return jsonify({'error': 'Sem permissão para visualizar este funcionário'}), 403

        funcionario = User.query.get_or_404(funcionario_id)
        return jsonify(funcionario.to_dict()), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@funcionarios_bp.route('/funcionarios/<int:funcionario_id>', methods=['PUT'])
@require_auth
def update_funcionario(funcionario_id):
    try:
        current_user = User.query.get(session['user_id'])
        funcionario = User.query.get_or_404(funcionario_id)
        
        # Apenas admin ou o próprio usuário pode editar
        if not current_user.is_admin and current_user.id != funcionario_id:
            return jsonify({'error': 'Sem permissão para editar este funcionário'}), 403

        data = request.get_json()

        # Campos que podem ser editados
        if 'nome' in data:
            funcionario.nome = data['nome']
        if 'departamento' in data:
            funcionario.departamento = data['departamento']
        if 'funcao' in data:
            funcionario.funcao = data['funcao']
        if 'salario' in data:
            funcionario.salario = float(data['salario'])
        
        # Apenas admin pode alterar permissões
        if current_user.is_admin:
            if 'pode_ver_funcionarios' in data:
                funcionario.pode_ver_funcionarios = data['pode_ver_funcionarios']
            if 'is_admin' in data:
                funcionario.is_admin = data['is_admin']

        # Alterar senha
        if 'password' in data and data['password']:
            funcionario.set_password(data['password'])

        db.session.commit()

        return jsonify({
            'message': 'Funcionário atualizado com sucesso',
            'funcionario': funcionario.to_dict()
        }), 200

    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@funcionarios_bp.route('/funcionarios/<int:funcionario_id>', methods=['DELETE'])
@require_auth
def delete_funcionario(funcionario_id):
    try:
        current_user = User.query.get(session['user_id'])
        
        # Apenas admin pode deletar funcionários
        if not current_user.is_admin:
            return jsonify({'error': 'Apenas administradores podem deletar funcionários'}), 403

        # Não pode deletar a si mesmo
        if current_user.id == funcionario_id:
            return jsonify({'error': 'Não é possível deletar seu próprio usuário'}), 400

        funcionario = User.query.get_or_404(funcionario_id)
        db.session.delete(funcionario)
        db.session.commit()

        return jsonify({'message': 'Funcionário deletado com sucesso'}), 200

    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@funcionarios_bp.route('/departamentos', methods=['GET'])
@require_auth
def get_departamentos():
    try:
        departamentos = db.session.query(User.departamento).distinct().all()
        return jsonify([departamento[0] for departamento in departamentos]), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

