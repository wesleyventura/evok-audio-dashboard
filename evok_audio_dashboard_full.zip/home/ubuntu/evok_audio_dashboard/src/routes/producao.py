from flask import Blueprint, request, jsonify, session
from datetime import datetime, date
import pytz
from ..models.user import db, Producao, Produto, User
from .auth import require_auth

producao_bp = Blueprint('producao', __name__)

@producao_bp.route('/producao', methods=['GET'])
@require_auth
def get_producoes():
    try:
        user_id = session.get('user_id')
        user = User.query.get(user_id)
        
        # Filtros opcionais
        data_inicio = request.args.get('data_inicio')
        data_fim = request.args.get('data_fim')
        produto_id = request.args.get('produto_id')
        categoria = request.args.get('categoria')
        status = request.args.get('status')

        query = Producao.query
        
        # Filtrar por usuário se não for admin
        if not user.is_admin:
            query = query.filter(Producao.user_id == user_id)

        if data_inicio:
            query = query.filter(Producao.data_inicio >= datetime.strptime(data_inicio, '%Y-%m-%d').date())
        if data_fim:
            query = query.filter(Producao.data_inicio <= datetime.strptime(data_fim, '%Y-%m-%d').date())
        if produto_id:
            query = query.filter(Producao.produto_id == produto_id)
        if categoria:
            query = query.join(Produto).filter(Produto.categoria == categoria)
        if status:
            query = query.filter(Producao.status == status)

        producoes = query.order_by(Producao.created_at.desc()).all()
        return jsonify([producao.to_dict() for producao in producoes]), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@producao_bp.route('/producao', methods=['POST'])
@require_auth
def create_producao():
    try:
        data = request.get_json()
        
        required_fields = ['data_inicio', 'ordem_producao', 'horario_inicio', 'produto_id', 'quantidade_produzida', 'funcionarios_ids']
        for field in required_fields:
            if not data.get(field):
                return jsonify({'error': f'Campo {field} é obrigatório'}), 400

        # Verificar se o produto existe
        produto = Produto.query.get(data['produto_id'])
        if not produto:
            return jsonify({'error': 'Produto não encontrado'}), 404

        # Verificar se a ordem de produção já existe
        existing_producao = Producao.query.filter_by(ordem_producao=data['ordem_producao']).first()
        if existing_producao:
            return jsonify({'error': 'Ordem de produção já existe'}), 400

        # Verificar se os funcionários existem
        funcionarios_ids = data['funcionarios_ids']
        if not isinstance(funcionarios_ids, list) or len(funcionarios_ids) == 0:
            return jsonify({'error': 'Pelo menos um funcionário deve ser selecionado'}), 400

        funcionarios = User.query.filter(User.id.in_(funcionarios_ids)).all()
        if len(funcionarios) != len(funcionarios_ids):
            return jsonify({'error': 'Um ou mais funcionários não foram encontrados'}), 404

        # Converter horário de início para fuso horário de Brasília
        brasilia_tz = pytz.timezone('America/Sao_Paulo')
        horario_inicio_local = datetime.strptime(data['horario_inicio'], '%Y-%m-%dT%H:%M')
        
        producao = Producao(
            data_inicio=datetime.strptime(data['data_inicio'], '%Y-%m-%d').date(),
            ordem_producao=data['ordem_producao'],
            horario_inicio=horario_inicio_local,
            produto_id=data['produto_id'],
            user_id=session['user_id'],
            quantidade_produzida=float(data['quantidade_produzida']),
            observacoes=data.get('observacoes', ''),
            status='pendente'
        )

        # Adicionar funcionários à produção
        producao.funcionarios = funcionarios

        db.session.add(producao)
        db.session.commit()

        return jsonify({
            'message': 'Produção iniciada com sucesso',
            'producao': producao.to_dict()
        }), 201

    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@producao_bp.route('/producao/<int:producao_id>/finalizar', methods=['PUT'])
@require_auth
def finalizar_producao(producao_id):
    try:
        producao = Producao.query.get_or_404(producao_id)
        
        # Verificar se a produção pertence ao usuário atual ou se é admin
        current_user = User.query.get(session['user_id'])
        if producao.user_id != current_user.id and not current_user.is_admin:
            return jsonify({'error': 'Sem permissão para finalizar esta produção'}), 403

        if producao.status == 'finalizada':
            return jsonify({'error': 'Produção já foi finalizada'}), 400

        # Finalizar produção com fuso horário de Brasília
        brasilia_tz = pytz.timezone('America/Sao_Paulo')
        producao.horario_fim = datetime.now(brasilia_tz).replace(tzinfo=None)
        producao.status = 'finalizada'

        # Atualizar quantidade se fornecida
        data = request.get_json()
        if data and 'quantidade_produzida' in data:
            producao.quantidade_produzida = float(data['quantidade_produzida'])

        db.session.commit()

        return jsonify({
            'message': 'Produção finalizada com sucesso',
            'producao': producao.to_dict()
        }), 200

    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@producao_bp.route('/producao/<int:producao_id>', methods=['PUT'])
@require_auth
def update_producao(producao_id):
    try:
        producao = Producao.query.get_or_404(producao_id)
        
        # Verificar permissões
        current_user = User.query.get(session['user_id'])
        if producao.user_id != current_user.id and not current_user.is_admin:
            return jsonify({'error': 'Sem permissão para editar esta produção'}), 403

        data = request.get_json()

        # Campos que podem ser editados
        if 'quantidade_produzida' in data:
            producao.quantidade_produzida = float(data['quantidade_produzida'])
        if 'observacoes' in data:
            producao.observacoes = data['observacoes']
        if 'funcionarios_ids' in data:
            funcionarios_ids = data['funcionarios_ids']
            if isinstance(funcionarios_ids, list) and len(funcionarios_ids) > 0:
                funcionarios = User.query.filter(User.id.in_(funcionarios_ids)).all()
                if len(funcionarios) == len(funcionarios_ids):
                    producao.funcionarios = funcionarios
                else:
                    return jsonify({'error': 'Um ou mais funcionários não foram encontrados'}), 404

        db.session.commit()

        return jsonify({
            'message': 'Produção atualizada com sucesso',
            'producao': producao.to_dict()
        }), 200

    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@producao_bp.route('/producao/<int:producao_id>', methods=['DELETE'])
@require_auth
def delete_producao(producao_id):
    try:
        current_user = User.query.get(session['user_id'])
        
        # Apenas admin pode deletar produções
        if not current_user.is_admin:
            return jsonify({'error': 'Apenas administradores podem deletar produções'}), 403

        producao = Producao.query.get_or_404(producao_id)
        db.session.delete(producao)
        db.session.commit()

        return jsonify({'message': 'Produção deletada com sucesso'}), 200

    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@producao_bp.route('/producao/pendentes', methods=['GET'])
@require_auth
def get_producoes_pendentes():
    try:
        user_id = session.get('user_id')
        user = User.query.get(user_id)
        
        if user.is_admin:
            # Admin vê todas as produções pendentes
            producoes = Producao.query.filter_by(status='pendente').all()
        else:
            # Usuário comum vê apenas suas produções pendentes
            producoes = Producao.query.filter_by(user_id=user_id, status='pendente').all()
            
        return jsonify([producao.to_dict() for producao in producoes]), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

