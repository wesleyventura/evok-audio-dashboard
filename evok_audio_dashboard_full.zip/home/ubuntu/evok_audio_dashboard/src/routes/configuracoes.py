from flask import Blueprint, request, jsonify, session
from src.models.user import db, User
from src.routes.auth import require_admin

configuracoes_bp = Blueprint('configuracoes', __name__)

@configuracoes_bp.route('/configuracoes/usuarios', methods=['GET'])
@require_admin
def get_usuarios_configuracoes():
    try:
        usuarios = User.query.all()
        return jsonify([{
            'id': user.id,
            'username': user.username,
            'nome': user.nome,
            'departamento': user.departamento,
            'funcao': user.funcao,
            'is_admin': user.is_admin,
            'pode_ver_funcionarios': user.pode_ver_funcionarios
        } for user in usuarios]), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@configuracoes_bp.route('/configuracoes/usuarios/<int:user_id>/permissoes', methods=['PUT'])
@require_admin
def update_permissoes_usuario(user_id):
    try:
        user = User.query.get_or_404(user_id)
        data = request.get_json()

        # Não permitir que o admin remova suas próprias permissões
        current_user_id = session['user_id']
        if user_id == current_user_id and 'is_admin' in data and not data['is_admin']:
            return jsonify({'error': 'Não é possível remover suas próprias permissões de administrador'}), 400

        if 'pode_ver_funcionarios' in data:
            user.pode_ver_funcionarios = data['pode_ver_funcionarios']
        
        if 'is_admin' in data:
            user.is_admin = data['is_admin']

        db.session.commit()

        return jsonify({
            'message': 'Permissões atualizadas com sucesso',
            'user': {
                'id': user.id,
                'username': user.username,
                'nome': user.nome,
                'is_admin': user.is_admin,
                'pode_ver_funcionarios': user.pode_ver_funcionarios
            }
        }), 200

    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

