from flask import Blueprint, request, jsonify, session
from src.models.user import db, Produto, User
from src.routes.auth import require_auth

produtos_bp = Blueprint('produtos', __name__)

@produtos_bp.route('/produtos', methods=['GET'])
@require_auth
def get_produtos():
    try:
        user_id = session.get('user_id')
        user = User.query.get(user_id)
        
        if user.is_admin:
            # Admin vê todos os produtos
            produtos = Produto.query.all()
        else:
            # Usuário comum vê apenas seus produtos
            produtos = Produto.query.filter_by(user_id=user_id).all()
            
        return jsonify([produto.to_dict() for produto in produtos]), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@produtos_bp.route('/produtos', methods=['POST'])
@require_auth
def create_produto():
    try:
        data = request.get_json()
        user_id = session.get('user_id')
        
        required_fields = ['nome', 'categoria', 'qtd_produzida_por_hora_funcionario']
        for field in required_fields:
            if not data.get(field):
                return jsonify({'error': f'Campo {field} é obrigatório'}), 400

        produto = Produto(
            nome=data['nome'],
            categoria=data['categoria'],
            qtd_produzida_por_hora_funcionario=float(data['qtd_produzida_por_hora_funcionario']),
            user_id=user_id  # Associa o produto ao usuário logado
        )

        db.session.add(produto)
        db.session.commit()

        return jsonify({
            'message': 'Produto criado com sucesso',
            'produto': produto.to_dict()
        }), 201

    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@produtos_bp.route('/produtos/<int:produto_id>', methods=['PUT'])
@require_auth
def update_produto(produto_id):
    try:
        user_id = session.get('user_id')
        user = User.query.get(user_id)
        produto = Produto.query.get_or_404(produto_id)
        
        # Verifica se o usuário pode editar este produto
        if not user.is_admin and produto.user_id != user_id:
            return jsonify({'error': 'Sem permissão para editar este produto'}), 403
        
        data = request.get_json()

        if 'nome' in data:
            produto.nome = data['nome']
        if 'categoria' in data:
            produto.categoria = data['categoria']
        if 'qtd_produzida_por_hora_funcionario' in data:
            produto.qtd_produzida_por_hora_funcionario = float(data['qtd_produzida_por_hora_funcionario'])

        db.session.commit()

        return jsonify({
            'message': 'Produto atualizado com sucesso',
            'produto': produto.to_dict()
        }), 200

    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@produtos_bp.route('/produtos/<int:produto_id>', methods=['DELETE'])
@require_auth
def delete_produto(produto_id):
    try:
        user_id = session.get('user_id')
        user = User.query.get(user_id)
        produto = Produto.query.get_or_404(produto_id)
        
        # Verifica se o usuário pode deletar este produto
        if not user.is_admin and produto.user_id != user_id:
            return jsonify({'error': 'Sem permissão para deletar este produto'}), 403
        
        db.session.delete(produto)
        db.session.commit()

        return jsonify({'message': 'Produto deletado com sucesso'}), 200

    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@produtos_bp.route('/categorias', methods=['GET'])
@require_auth
def get_categorias():
    try:
        user_id = session.get('user_id')
        user = User.query.get(user_id)
        
        if user.is_admin:
            # Admin vê todas as categorias
            categorias = db.session.query(Produto.categoria).distinct().all()
        else:
            # Usuário comum vê apenas categorias dos seus produtos
            categorias = db.session.query(Produto.categoria).filter_by(user_id=user_id).distinct().all()
            
        return jsonify([categoria[0] for categoria in categorias]), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

