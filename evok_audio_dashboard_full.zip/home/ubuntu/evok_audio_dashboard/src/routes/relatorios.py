from flask import Blueprint, request, jsonify, session
from src.models.user import db, Producao, Produto, User
from src.routes.auth import require_auth
from datetime import datetime
from sqlalchemy import func

relatorios_bp = Blueprint('relatorios', __name__)

@relatorios_bp.route('/relatorios/producao', methods=['GET'])
@require_auth
def relatorio_producao():
    try:
        user_id = session.get('user_id')
        user = User.query.get(user_id)
        
        # Filtros
        data_inicio = request.args.get('data_inicio')
        data_fim = request.args.get('data_fim')
        categoria = request.args.get('categoria')
        produto_id = request.args.get('produto_id')

        query = Producao.query.filter_by(status='finalizada')
        
        # Filtrar por usuário se não for admin
        if not user.is_admin:
            query = query.filter(Producao.user_id == user_id)

        if data_inicio:
            query = query.filter(Producao.data_inicio >= datetime.strptime(data_inicio, '%Y-%m-%d').date())
        if data_fim:
            query = query.filter(Producao.data_inicio <= datetime.strptime(data_fim, '%Y-%m-%d').date())
        if categoria:
            query = query.join(Produto).filter(Produto.categoria == categoria)
        if produto_id:
            query = query.filter(Producao.produto_id == produto_id)

        producoes = query.order_by(Producao.data_inicio.desc()).all()

        # Calcular estatísticas
        total_producoes = len(producoes)
        total_horas = sum([p.horas_trabalhadas for p in producoes])
        total_quantidade_produzida = sum([p.quantidade_produzida for p in producoes])
        total_quantidade_esperada = sum([p.quantidade_esperada for p in producoes])
        
        eficiencia_media = 0
        if total_quantidade_esperada > 0:
            eficiencia_media = (total_quantidade_produzida / total_quantidade_esperada) * 100
        
        # Estatísticas por departamento
        departamentos_stats = {}
        total_custo_mao_obra = 0
        
        for producao in producoes:
            dept = producao.user.departamento
            if dept not in departamentos_stats:
                departamentos_stats[dept] = {
                    'total_producoes': 0,
                    'total_horas': 0,
                    'total_quantidade_produzida': 0,
                    'total_quantidade_esperada': 0,
                    'total_custo_mao_obra': 0,
                    'eficiencia_media': 0
                }
            
            departamentos_stats[dept]['total_producoes'] += 1
            departamentos_stats[dept]['total_horas'] += producao.horas_trabalhadas
            departamentos_stats[dept]['total_quantidade_produzida'] += producao.quantidade_produzida
            departamentos_stats[dept]['total_quantidade_esperada'] += producao.quantidade_esperada
            departamentos_stats[dept]['total_custo_mao_obra'] += producao.custo_mao_obra
            
            total_custo_mao_obra += producao.custo_mao_obra

        # Calcular eficiência por departamento
        for dept in departamentos_stats:
            if departamentos_stats[dept]['total_quantidade_esperada'] > 0:
                departamentos_stats[dept]['eficiencia_media'] = (
                    departamentos_stats[dept]['total_quantidade_produzida'] / 
                    departamentos_stats[dept]['total_quantidade_esperada']
                ) * 100

        return jsonify({
            'producoes': [p.to_dict() for p in producoes],
            'estatisticas': {
                'total_producoes': total_producoes,
                'total_horas': total_horas,
                'total_quantidade_produzida': total_quantidade_produzida,
                'total_quantidade_esperada': total_quantidade_esperada,
                'total_custo_mao_obra': total_custo_mao_obra,
                'eficiencia_media': eficiencia_media,
                'departamentos': departamentos_stats
            }
        }), 200

    except Exception as e:
        return jsonify({'error': str(e)}), 500

@relatorios_bp.route('/dashboard/metricas', methods=['GET'])
@require_auth
def dashboard_metricas():
    try:
        user_id = session.get('user_id')
        user = User.query.get(user_id)
        
        # Filtros
        data_inicio = request.args.get('data_inicio')
        data_fim = request.args.get('data_fim')
        categoria = request.args.get('categoria')
        produto_id = request.args.get('produto_id')

        query = Producao.query.filter_by(status='finalizada')
        
        # Filtrar por usuário se não for admin
        if not user.is_admin:
            query = query.filter(Producao.user_id == user_id)

        if data_inicio:
            query = query.filter(Producao.data_inicio >= datetime.strptime(data_inicio, '%Y-%m-%d').date())
        if data_fim:
            query = query.filter(Producao.data_inicio <= datetime.strptime(data_fim, '%Y-%m-%d').date())
        if categoria:
            query = query.join(Produto).filter(Produto.categoria == categoria)
        if produto_id:
            query = query.filter(Producao.produto_id == produto_id)

        producoes = query.all()

        # Categoria mais produzida
        categoria_stats = {}
        for producao in producoes:
            cat = producao.produto.categoria
            if cat not in categoria_stats:
                categoria_stats[cat] = 0
            categoria_stats[cat] += producao.quantidade_produzida

        categoria_mais_produzida = max(categoria_stats.items(), key=lambda x: x[1]) if categoria_stats else ('N/A', 0)

        # Departamento que mais produziu
        dept_stats = {}
        for producao in producoes:
            dept = producao.user.departamento
            if dept not in dept_stats:
                dept_stats[dept] = 0
            dept_stats[dept] += producao.quantidade_produzida

        dept_mais_produziu = max(dept_stats.items(), key=lambda x: x[1]) if dept_stats else ('N/A', 0)

        # Produto mais produzido
        produto_stats = {}
        for producao in producoes:
            produto = producao.produto.nome
            if produto not in produto_stats:
                produto_stats[produto] = 0
            produto_stats[produto] += producao.quantidade_produzida

        produto_mais_produzido = max(produto_stats.items(), key=lambda x: x[1]) if produto_stats else ('N/A', 0)

        # Departamento com melhor resultado (eficiência)
        dept_eficiencia = {}
        for producao in producoes:
            dept = producao.user.departamento
            if dept not in dept_eficiencia:
                dept_eficiencia[dept] = {'produzida': 0, 'esperada': 0}
            dept_eficiencia[dept]['produzida'] += producao.quantidade_produzida
            dept_eficiencia[dept]['esperada'] += producao.quantidade_esperada

        melhor_dept = ('N/A', 0)
        for dept, stats in dept_eficiencia.items():
            if stats['esperada'] > 0:
                eficiencia = (stats['produzida'] / stats['esperada']) * 100
                if eficiencia > melhor_dept[1]:
                    melhor_dept = (dept, eficiencia)

        # Custo de mão de obra por produto
        custo_produto = {}
        for producao in producoes:
            produto = producao.produto.nome
            if produto not in custo_produto:
                custo_produto[produto] = 0
            custo_produto[produto] += producao.custo_mao_obra

        # Custo de mão de obra por categoria
        custo_categoria = {}
        for producao in producoes:
            categoria = producao.produto.categoria
            if categoria not in custo_categoria:
                custo_categoria[categoria] = 0
            custo_categoria[categoria] += producao.custo_mao_obra

        return jsonify({
            'categoria_mais_produzida': {
                'nome': categoria_mais_produzida[0],
                'quantidade': categoria_mais_produzida[1]
            },
            'departamento_mais_produziu': {
                'nome': dept_mais_produziu[0],
                'quantidade': dept_mais_produziu[1]
            },
            'produto_mais_produzido': {
                'nome': produto_mais_produzido[0],
                'quantidade': produto_mais_produzido[1]
            },
            'departamento_melhor_resultado': {
                'nome': melhor_dept[0],
                'eficiencia': melhor_dept[1]
            },
            'custo_mao_obra_produto': custo_produto,
            'custo_mao_obra_categoria': custo_categoria,
            'estatisticas_departamentos': dept_eficiencia
        }), 200

    except Exception as e:
        return jsonify({'error': str(e)}), 500

